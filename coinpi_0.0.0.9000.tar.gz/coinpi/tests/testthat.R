library(testthat)
library(coinpi)

test_check("coinpi")
